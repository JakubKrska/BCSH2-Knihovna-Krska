Semestrální práce BCSH2 na téma Knihovna, odprezentovano musim dodelam do 20.12 a obhajit 12.12 nebo 19.12 to musi byt hotovo
