﻿namespace KrskaKnihovna.Models
{
    public enum EnumPossibilities
    {
        Libraries,
        Books,
        Customers,
        Loans
    }
}
